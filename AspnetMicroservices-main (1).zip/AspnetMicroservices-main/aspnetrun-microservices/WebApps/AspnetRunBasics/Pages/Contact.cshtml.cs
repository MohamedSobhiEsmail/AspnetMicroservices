﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AspnetRunBasics
{
    public class ContactModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}