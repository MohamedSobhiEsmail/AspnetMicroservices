﻿namespace EventBus.Messages.Common;
public struct EventBusConstants
{
    public const string BasketCheckoutQueue = "basketcheckout-queue";
}